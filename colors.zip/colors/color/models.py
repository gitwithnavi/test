from django.db import models
class color(models.Model):
  firstname = models.CharField(max_length=255)
  lastname = models.CharField(max_length=255)
  
  
class images(models.Model):

  image=models.ImageField(blank=True, null=True)

# Create your models here.