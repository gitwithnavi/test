from django.contrib import admin
from .models import color
from .models import images
admin.site.register(color)
admin.site.register(images)

# Register your models here.
