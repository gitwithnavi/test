from audioop import reverse
from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.urls import reverse_lazy
from .models import color

def index(request):
  mymembers = color.objects.all().values()
  template = loader.get_template('a.html')
  context = {
    'mymembers': mymembers,
  }
  return HttpResponse(template.render(context, request))

def add(request):
  template = loader.get_template('add.html')
  return HttpResponse(template.render({}, request))
# Create your views here.

def addrecord(request):
  x = request.POST['first']
  y = request.POST['last']
  member = color(firstname=x, lastname=y)
  member.save()
  return HttpResponseRedirect(reverse_lazy('a'))

def delete(request, id):
  member = color.objects.get(id=id)
  member.delete()
  return HttpResponseRedirect(reverse_lazy('a'))
  
def image(request):
   x=request.POST['image']  
   memberss = images(image=x)
   memberss.save()
   return HttpResponseRedirect(reverse_lazy('a'))
   mymembers = images.objects.all().values()
   template = loader.get_template('a.html')
   context = {
     'mymembers': mymembers,
   }
   return HttpResponse(template.render(context, request))
   

  
  #return render('index',request)
